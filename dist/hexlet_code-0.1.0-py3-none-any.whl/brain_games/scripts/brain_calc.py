from brain_games.logic.games_logic import calc_game

def main():
    calc_game()

if __name__ == '__main__':
    main()
