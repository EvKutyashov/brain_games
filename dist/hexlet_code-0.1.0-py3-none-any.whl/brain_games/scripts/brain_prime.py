from brain_games.logic.games_logic import prime

def main():
    prime()

if __name__ == '__main__':
    main()
