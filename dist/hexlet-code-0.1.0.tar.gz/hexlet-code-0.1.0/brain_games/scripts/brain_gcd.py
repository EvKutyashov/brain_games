from brain_games.logic.games_logic import gcd_game

def main():
    gcd_game()

if __name__ == '__main__':
    main()
