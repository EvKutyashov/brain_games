from brain_games.logic.games_logic import find_skipped_number

def main():
    find_skipped_number()

if __name__ == '__main__':
    main()
